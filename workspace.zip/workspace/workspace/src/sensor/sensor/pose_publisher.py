import math
import numpy as np
import serial
import time
import sys


import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose





class PosePublisher(Node):

    def __init__(self): # Setup Arduino
        super().__init__('turtle_tf2_frame_publisher')

        # Declare and acquire turtlename parameter
        self.turtlename = self.declare_parameter(
          'turtlename', 'turtle').get_parameter_value().string_value

        self.publisher_ = self.create_publisher(Pose, 
                                                f'/{self.turtlename}/pose', 
                                                10)
        
        timer_period = 0.001  # seconds
        self.timer = self.create_timer(timer_period, self.loop)

        ### Configuración valores pose total
        self.xdef = 0.0
        self.ydef = 0.0
        self.valtheta = 0.0

        self.xp1 = 0.0
        self.yp1 = 0.0
        self.thetap1 = 0.0

        self.xp2 = 0.0
        self.yp2 = 0.0
        self.thetap2 = 0.0

        self.xp3 = 0.0
        self.yp3 = 0.0
        self.thetap3 = 0.0

        ##conexión serial
        self.arduino = serial.Serial('/dev/ttyACM0', 115200)
        time.sleep(2) 
        # Inicialización de listas para almacenar datos de sensores
        self.sensor1_data = [1,0,0]
        self.sensor2_data = [2,0,0]
        self.sensor3_data = [3,0,0]
        # otras variables inicialización
        #pareja 1  1-2
        self.delta_x_1 = 0.0
        self.delta_y_1 = 0.0
        self.last_xdef_1 = 0.0
        self.last_ydef_1 = 0.0
        self.delta_theta_1 = 0.0
        self.last_theta_1 = 0.0
        self.D1 = 150 
        self.current_x1 = None
        self.current_y1 = None
        self.last_x1 = None
        self.last_y1 = None
        self.current_x2 = None
        self.current_y2 = None
        self.last_x2 = None
        self.last_y2 = None
        self.xdiff1 = 0.0
        self.xdiff2 = 0.0
        self.ydiff1 = 0.0
        self.ydiff2 = 0.0

        #pareja  2  1-3
        self.delta_x_2= 0.0
        self.delta_y_2 = 0.0
        self.last_xdef_2 = 0.0
        self.last_ydef_2 = 0.0
        self.delta_theta_2 = 0.0
        self.last_theta_2 = 0.0
        self.D2 = 200 
        self.current_x3 = None
        self.current_y3 = None
        self.last_x3 = None
        self.last_y3 = None
        self.xdiff3 = 0.0
        self.ydiff3 = 0.0

        #pareja 3   3-2
        self.delta_x_3 = 0.0
        self.delta_y_3 = 0.0
        self.last_xdef_3 = 0.0
        self.last_ydef_3 = 0.0
        self.delta_theta_3 = 0.0
        self.last_theta_3 = 0.0
        self.D3 = 200 

    
        self.delta_theta = 0.0
        self.last_theta = 0.0
        self.last_xdef = 0.0
        self.last_ydef = 0.0
        
        

        # Abrir archivos para guardar datos de cada par de sensores y
        # fusión de sensores en tiempo de muestreo
        self.file2 = open('pose_data1p.txt', 'a')
        self.file3 = open('pose_data2p.txt', 'a')
        self.file4 = open('pose_data3p.txt', 'a')
        self.file1 = open('pose_datafusion.txt', 'a')
         

    def loop(self): # Loop Arduino
                
        
        #########################################################
        
                # Leer datos del puerto serial de Arduino
                line = self.arduino.readline().decode().strip()
                data = line.split(',')

                # asigna datos de x y y a cada sensor
                if len(data) == 3:
                    if data[0] == '1':
                        self.sensor1_data = data[1:]
                        try:
                            self.current_x1, self.current_y1 = map(float, self.sensor1_data[:2])
                            
                        except ValueError:
                            pass
                        
                    elif data[0] == '2':
                        self.sensor2_data = data[1:]
                        try:
                            self.current_x2, self.current_y2 = map(float, self.sensor2_data[:2])
                           
                        except ValueError:
                            pass
                    
                    elif data[0] == '3':
                        self.sensor3_data = data[1:]
                        try:
                            self.current_x3, self.current_y3 = map(float, self.sensor3_data[:2])
                           
                        except ValueError:
                            pass
                    

                ## COMIENZA CON CÁLCULO DE DELTA THETA Y THETA, X, Y EN EL t+1
                

                    if (self.last_x1 is not None and self.last_y1 is not None and self.last_x2 is not None and
                        self.last_y2 is not None and self.last_x3 is not None and self.last_y3 is not None): 
                        self.xdiff1 = self.current_x1 - self.last_x1
                        self.xdiff2 = self.current_x2 - self.last_x2
                        self.xdiff3 = self.current_x3 - self.last_x3
                        self.ydiff1 = self.current_y1 - self.last_y1
                        self.ydiff2 = self.current_y2 - self.last_y2
                        self.ydiff3 = self.current_y3 - self.last_y3
                    
                    

                    # #ENTONCES DELTA X y DELTA Y 
                    #pareja 1 (1-2)
                    self.delta_y_1 = (self.ydiff2 + self.ydiff1) /2
                    self.delta_x_1 = (self.xdiff1 + self.xdiff2) /2 
                    #pareja 2 (1-3)
                    self.delta_y_2 = (self.ydiff1 + self.ydiff3) /2
                    self.delta_x_2 = (self.xdiff1 + self.xdiff3) /2 
                    #pareja 3 (2-3)
                    self.delta_y_3 = (self.ydiff2 + self.ydiff3) /2
                    self.delta_x_3 = (self.xdiff2 + self.xdiff3) /2 


                    # #DELTA THETA 
                
                    self.delta_theta_1 = 2 * np.arctan((self.ydiff2 - self.ydiff1) /(self.D1 * 2)) #pareja 1 (1-2)
                    self.delta_theta_2 = 2 * np.arctan((self.ydiff3 - self.ydiff1) /(self.D2 * 2)) #pareja 2 (1-3)
                    self.delta_theta_3 = 2 * np.arctan((self.ydiff2 - self.ydiff3) /(self.D3 * 2))  #pareja 3 (3-2)

                    #THETA 
                    self.thetap1 = self.last_theta_1 + self.delta_theta_1
                    self.thetap2 = self.last_theta_2 + self.delta_theta_2
                    self.thetap3 = self.last_theta_3 + self.delta_theta_3

                    self.valtheta = (self.thetap1 + self.thetap2 + self.thetap3) /3
                    
                    #POSITION 
                    self.xp1 = self.last_xdef_1 - (self.delta_y_1 * np.sin(self.last_theta_1)) + (self.delta_x_1 * np.cos(self.last_theta_1))
                    self.yp1 = self.last_ydef_1 + (self.delta_y_1 * np.cos(self.last_theta_1)) + (self.delta_x_1 * np.sin(self.last_theta_1))
                    
                    self.xp2 = self.last_xdef_2 - (self.delta_y_2 * np.sin(self.last_theta_2)) + (self.delta_x_2 * np.cos(self.last_theta_2))
                    self.yp2 = self.last_ydef_2 + (self.delta_y_2 * np.cos(self.last_theta_2)) + (self.delta_x_2 * np.sin(self.last_theta_2))
        
                    self.xp3 = self.last_xdef_3 - (self.delta_y_3 * np.sin(self.last_theta_3)) + (self.delta_x_3 * np.cos(self.last_theta_3))
                    self.yp3 = self.last_ydef_3 + (self.delta_y_3 * np.cos(self.last_theta_3)) + (self.delta_x_3 * np.sin(self.last_theta_3))
        
                    
                    self.xdef = (self.xp1 + self.xp2 + self.xp3 ) /3
                    self.ydef = (self.yp1 + self.yp2 + self.yp3) /3

                # ACTUALIZACIONES
                ## Current y def => t => t+1
                ## Last=> t-1 => t
                
                self.last_x1 = self.current_x1
                self.last_y1 = self.current_y1
                self.last_x2 = self.current_x2
                self.last_y2 = self.current_y2
                self.last_x3 = self.current_x3
                self.last_y3 = self.current_y3
                
                
                self.last_xdef_1 = self.xp1
                self.last_ydef_1 = self.yp1
                self.last_theta_1 = self.thetap1

                self.last_xdef_2 = self.xp2
                self.last_ydef_2 = self.yp2
                self.last_theta_2 = self.thetap2

                self.last_xdef_3 = self.xp3
                self.last_ydef_3 = self.yp3
                self.last_theta_3 = self.thetap3

                
                
                # Convertir valtheta a grados para guardar
                self.valthetadegrees = math.degrees(self.valtheta)
                # Escribir en archivo
                self.file1.write(f"{self.xdef},{self.ydef},{self.valthetadegrees}\n")

                # Convertir valtheta a grados para guardar
                self.valthetadegrees1 = math.degrees(self.thetap1)
                # Escribir en archivo
                self.file2.write(f"{self.xp1},{self.yp1},{self.valthetadegrees1}\n")

                # Convertir valtheta a grados para guardar
                self.valthetadegrees2 = math.degrees(self.thetap2)
                # Escribir en archivo
                self.file3.write(f"{self.xp2},{self.yp2},{self.valthetadegrees2}\n")

                # Convertir valtheta a grados para guardar
                self.valthetadegrees3 = math.degrees(self.thetap3)
                # Escribir en archivo
                self.file4.write(f"{self.xp3},{self.yp3},{self.valthetadegrees3}\n")
                
          
        #########################################################
                pose = Pose()
                pose.x = self.xdef / 10
                pose.y = self.ydef / 10
                pose.theta = self.valtheta
                self.publisher_.publish(pose)

                print(f"Raw data from Arduino: {line}")

        

def main():
    rclpy.init()
    node = PosePublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass


    rclpy.shutdown()

