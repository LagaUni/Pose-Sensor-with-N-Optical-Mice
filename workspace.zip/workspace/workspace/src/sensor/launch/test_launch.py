from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='sensor',
            executable='tf_dynamic',
            name='dynamic_broadcaster',
            parameters=[
                {'turtlename': 'center'}
            ]
        ),
        Node(
            package='sensor',
            executable='odom_publish',
            name='odometry_publisher',
            parameters=[
                {'turtlename': 'center'}
            ]
        ),
        Node(
            package='sensor',
            executable='pose_publisher',
            name='pose_publisher',
            parameters=[
                {'turtlename': 'center'}
            ]
        ),
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            arguments = ['--x', '7.5', '--y', '0', '--z', '0', '--yaw', '0', '--pitch', '0', '--roll', '0', '--frame-id', 'center', '--child-frame-id', 'mouse1']
        ),
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            arguments = ['--x', '-7.5', '--y', '0', '--z', '0', '--yaw', '0', '--pitch', '0', '--roll', '0', '--frame-id', 'center', '--child-frame-id', 'mouse2']
        ),
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            arguments = ['--x', '0', '--y', '13.5', '--z', '0', '--yaw', '0', '--pitch', '0', '--roll', '0', '--frame-id', 'center', '--child-frame-id', 'mouse3']
        ),
        Node(
            package='rviz2',
            executable='rviz2'
        ),
    ])